<?php if (!empty($slug) && $slug === 'video-production-editing'): ?>
<section class="video-reel-section">
  <style>
    .video-reel-section{padding:80px 0}
    .video-reel-section .reveal{opacity:1 !important;transform:none !important}
    .video-reel-outer{position:relative;display:flex;align-items:center;gap:16px}
    .video-reel-track-wrap{overflow-x:auto;scroll-behavior:smooth;flex:1}
    .video-reel-track{display:flex;gap:20px}
    .video-reel-card{flex:0 0 260px;position:relative;border-radius:16px;overflow:hidden;background:#111;aspect-ratio:9/16}
    .video-reel-video{width:100%;height:100%;object-fit:cover;display:block}
    .video-reel-label{position:absolute;left:12px;bottom:12px;color:#fff;font-size:13px;background:rgba(0,0,0,.5);padding:4px 10px;border-radius:20px}
    .video-reel-arrow{flex:0 0 auto;width:44px;height:44px;border-radius:50%;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.05);color:#fff;font-size:18px;cursor:pointer}
    .video-reel-arrow:disabled{opacity:.3;cursor:default}
  </style>
  <div class="container">
    <div class="section-head">
      <div>
        <span class="eyebrow">REEL SHOWCASE</span>
        <h2>Hover to play short-form reels.</h2>
      </div>
    </div>

    <?php
    $reelFiles = [];
    $reelDir = __DIR__ . '/../assets/images/';
    if (is_dir($reelDir)) {
      $files = scandir($reelDir);
      if ($files !== false) {
        foreach ($files as $file) {
          if (preg_match('/^reel\d+\.mp4$/i', $file)) {
            $reelFiles[] = 'assets/images/' . $file;
          }
        }
      }
    }
    sort($reelFiles);
    if (empty($reelFiles)) {
      $reelFiles[] = 'assets/images/reel1.mp4';
    }
    ?>

    <div class="video-reel-outer">
      <button class="video-reel-arrow video-reel-prev" type="button" aria-label="Previous reel">←</button>
      <div class="video-reel-track-wrap">
        <div class="video-reel-track" id="videoReelTrack">
          <?php foreach ($reelFiles as $index => $reel): ?>
            <article class="video-reel-card reveal">
              <video class="video-reel-video" muted loop playsinline preload="metadata">
                <source src="<?=e($reel)?>" type="video/mp4">
              </video>
              <div class="video-reel-label">Reel <?=e($index + 1)?></div>
            </article>
          <?php endforeach; ?>
        </div>
      </div>
      <button class="video-reel-arrow video-reel-next" type="button" aria-label="Next reel">→</button>
    </div>
  </div>
</section>
<script>
(function () {
  const reelWrap = document.querySelector('.video-reel-track-wrap');
  const reelTrack = document.getElementById('videoReelTrack');
  const prevBtn = document.querySelector('.video-reel-prev');
  const nextBtn = document.querySelector('.video-reel-next');

  if (!reelWrap || !reelTrack || !prevBtn || !nextBtn) return;

  const cards = Array.from(reelTrack.querySelectorAll('.video-reel-card'));
  if (!cards.length) return;

  const step = () => {
    const firstCard = cards[0];
    const gap = parseFloat(window.getComputedStyle(reelTrack).gap || 0);
    return firstCard.getBoundingClientRect().width + gap;
  };

  function updateButtons() {
    prevBtn.disabled = reelWrap.scrollLeft <= 2;
    nextBtn.disabled = reelWrap.scrollLeft >= reelWrap.scrollWidth - reelWrap.clientWidth - 2;
  }

  prevBtn.addEventListener('click', () => {
    reelWrap.scrollBy({ left: -step(), behavior: 'smooth' });
  });

  nextBtn.addEventListener('click', () => {
    reelWrap.scrollBy({ left: step(), behavior: 'smooth' });
  });

  reelWrap.addEventListener('scroll', updateButtons);

  cards.forEach(card => {
    const video = card.querySelector('.video-reel-video');
    if (!video) return;

    card.addEventListener('mouseenter', () => {
      const playPromise = video.play();
      if (playPromise && typeof playPromise.catch === 'function') {
        playPromise.catch(() => {});
      }
    });

    card.addEventListener('mouseleave', () => {
      video.pause();
      video.currentTime = 0;
    });
  });

  updateButtons();
})();
</script>
<?php endif; ?>